function UserInfo() {}

function serveFood(food) {}
function serveIn() {}
function billNote() {}
function generateInVoice() {}

export { UserInfo, serveIn, serveFood, billNote, generateInVoice };
