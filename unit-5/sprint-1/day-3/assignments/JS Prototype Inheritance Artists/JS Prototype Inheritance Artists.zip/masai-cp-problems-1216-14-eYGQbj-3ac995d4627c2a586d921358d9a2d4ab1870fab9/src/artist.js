function Artist(name, skill, profession){}

var artistsObject = {}


// Do not change this
export {Artist, artistsObject};
