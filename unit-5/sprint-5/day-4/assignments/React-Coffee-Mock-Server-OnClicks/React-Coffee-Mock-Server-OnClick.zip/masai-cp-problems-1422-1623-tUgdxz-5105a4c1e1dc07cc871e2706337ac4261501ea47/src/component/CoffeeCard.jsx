import React from "react";

const CoffeeCard = () => {
  return <div></div>;
};

export default CoffeeCard;
