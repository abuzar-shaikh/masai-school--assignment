import React from "react";

const Coffee = () => {
  return (
    <div className="coffee_container">{/* map coffee into coffee card */}</div>
  );
};

export default Coffee;
