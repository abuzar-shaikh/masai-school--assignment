// import Courses ,Title and UserCard here
// keep a user object with mentioned properties and pass down to UserCard as prop
export default function App() {
  return <></>;
}
