export default function NonFiction() {
  return (
    <div data-testid='books-nonfiction'>
      <h1 data-testid='books-container-title'>{}</h1>

      <div className="books-container">
        {/* Display all Non-Fiction books here */}
      </div>
    </div>
  );
}
