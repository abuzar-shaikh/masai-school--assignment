import "./App.css";
function App() {
  return (
    <div className="App">
      <div data-testid="counter">{/* counter component */}</div>
    </div>
  );
}

export default App;
