import React from 'react'

export default function AllRoutes() {
    return (
        <div></div>
    )
}
