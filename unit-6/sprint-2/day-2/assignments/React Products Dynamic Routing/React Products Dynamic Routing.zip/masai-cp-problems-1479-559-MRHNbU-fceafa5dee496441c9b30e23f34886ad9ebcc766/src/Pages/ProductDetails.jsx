import React from 'react'

export default function ProductDetails() {

  return (
    <div data-testid = "product-details" >
      <div>
      {/* show product details here */}
      </div>
    </div>
  )
}
