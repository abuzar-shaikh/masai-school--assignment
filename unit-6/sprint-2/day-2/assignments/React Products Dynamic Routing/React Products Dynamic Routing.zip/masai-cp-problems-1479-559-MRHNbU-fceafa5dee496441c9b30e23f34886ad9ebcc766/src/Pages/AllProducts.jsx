import React from 'react'

export default function AllProducts() {

  return (
    <div>
      <div>All Products</div>
      <div data-testid = "products-wrapper">

      </div>
    </div>
  )
}
