import React from "react";
import { BrowserRouter } from "react-router-dom";

function App() {
  return <BrowserRouter>Add your code here</BrowserRouter>;
}

export default App;
