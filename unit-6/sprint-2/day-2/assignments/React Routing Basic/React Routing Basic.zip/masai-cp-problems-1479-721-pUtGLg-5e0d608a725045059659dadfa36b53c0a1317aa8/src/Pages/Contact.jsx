import React from 'react'

export default function Contact() {
    return (
        <div>
             <h1 className = "contact_page"  >Welcome to Contact Page</h1>
        </div>
    )
}
