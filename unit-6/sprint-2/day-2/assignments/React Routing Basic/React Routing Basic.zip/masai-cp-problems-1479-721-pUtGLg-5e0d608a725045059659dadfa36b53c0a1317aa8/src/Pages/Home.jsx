import React from 'react'

export default function Home() {
  return (
    <div>
      <h1 className = "home_page" >Welcome to Home Page</h1>
    </div>
  )
}
