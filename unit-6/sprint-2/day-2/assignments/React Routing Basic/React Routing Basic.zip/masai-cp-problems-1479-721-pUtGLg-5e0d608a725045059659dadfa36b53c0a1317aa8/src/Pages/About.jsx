import React from 'react'

export default function About() {
  return (
    <div>
      <h1 className="about_page">Welcome to About Page</h1>
    </div>
  )
}
