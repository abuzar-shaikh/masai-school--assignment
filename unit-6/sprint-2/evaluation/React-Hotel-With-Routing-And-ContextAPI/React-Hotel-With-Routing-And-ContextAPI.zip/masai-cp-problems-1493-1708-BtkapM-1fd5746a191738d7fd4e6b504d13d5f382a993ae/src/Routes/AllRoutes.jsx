import React from 'react'

export const AllRoutes = () => {
  return <div>{/* Add Routes here */}</div>;
}
