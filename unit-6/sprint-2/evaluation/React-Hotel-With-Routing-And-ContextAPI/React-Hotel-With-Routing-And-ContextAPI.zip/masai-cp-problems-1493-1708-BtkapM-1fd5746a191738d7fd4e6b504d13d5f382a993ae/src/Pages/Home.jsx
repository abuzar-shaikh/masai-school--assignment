import React from "react";

export const Home = () => {
  return (
    <div data-cy="welcome-text">
      {/* Add the message along with the link */}
    </div>
  );
};