import React from "react";

export const SingleRoom = () => {
  return <div data-testid="SingleRoom"></div>;
};
