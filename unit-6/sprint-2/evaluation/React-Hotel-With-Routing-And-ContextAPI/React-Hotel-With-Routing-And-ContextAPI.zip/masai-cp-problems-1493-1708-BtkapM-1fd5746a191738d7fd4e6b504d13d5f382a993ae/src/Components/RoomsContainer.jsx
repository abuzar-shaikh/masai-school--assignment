import React from "react";

export const RoomsContainer = () => {
  return <div data-testid="rooms-container"></div>;
};
