
function Navbar() {
    return(
        <div className = "navbar" >

        </div>
    )
}

export { Navbar }