import React from 'react'
import { Dashboard } from './Components/Dashboard'

export default function App() {

  return (
    <div>
        <Dashboard />
    </div>
  )
}
