import React from 'react'
import App from '../App'

export default function ThemeContextProvider() {
  return (
      <App />
  )
}
