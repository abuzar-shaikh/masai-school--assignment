import React from 'react'

export default function User() {
    
    return (
        <div data-testid = "user" >
            <input data-testid = "level" type = "range" />
        </div>
    )
}
