import React from 'react'

export const Dashboard = () => {
    return (
        <div >
            <h3 data-testid = "token" >Token: </h3>
            <button data-testid = "logout" >LOGOUT</button>
        </div>
    )
}
