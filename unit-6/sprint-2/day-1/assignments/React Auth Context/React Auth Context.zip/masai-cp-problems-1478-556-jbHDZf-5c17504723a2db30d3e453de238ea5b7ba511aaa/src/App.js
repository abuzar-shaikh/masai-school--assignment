import React from 'react'
import Login from './Components/Login'

export default function App() {

  return (
    <div>
        <Login />
    </div>
  )
}
