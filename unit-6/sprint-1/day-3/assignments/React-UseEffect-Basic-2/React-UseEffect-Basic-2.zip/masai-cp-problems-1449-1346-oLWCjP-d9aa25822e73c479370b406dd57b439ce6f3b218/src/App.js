
import React from "react";
function App() {
   
  return (
    <div className="App">
      <h1>Employees Dashboard</h1>
      <div className="employee">
        {/* add your employee dashboard component here */}
    
      </div>
      {/* add your pagination component here */}
   
    </div>
  );
}

export default App;
