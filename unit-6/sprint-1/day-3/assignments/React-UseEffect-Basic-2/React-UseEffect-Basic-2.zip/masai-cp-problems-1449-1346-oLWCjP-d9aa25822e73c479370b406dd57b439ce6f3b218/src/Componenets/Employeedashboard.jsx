

const Employeedashboard = () => {
  return (
    <table border="1px">
      <thead>
        <tr>
          <th>Name</th>
          <th>Department</th>
          <th>Image</th>
          <th>Gender</th>
          <th>Salary</th>
        </tr>
      </thead>
      <tbody>
        {/* map through the data and make use of EmployeeCard*/}
       {[].map((item)=>{        
                   
        })}
      </tbody>
    </table>   
  );
};

export default Employeedashboard;
