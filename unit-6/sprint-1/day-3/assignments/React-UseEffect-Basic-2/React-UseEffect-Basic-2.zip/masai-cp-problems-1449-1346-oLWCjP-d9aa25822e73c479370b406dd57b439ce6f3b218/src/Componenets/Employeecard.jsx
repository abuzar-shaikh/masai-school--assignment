export function EmployeeCard() {
  
    return (
    <tr className="item" >
      <td className="employee-card-name"></td>
      <td className="employee-card-department"></td>
      <td className="employee-card-image"></td>
      <td className="employee-card-gender"></td>
      <td className="employee-card-salary"></td>
    </tr>
  );
}
