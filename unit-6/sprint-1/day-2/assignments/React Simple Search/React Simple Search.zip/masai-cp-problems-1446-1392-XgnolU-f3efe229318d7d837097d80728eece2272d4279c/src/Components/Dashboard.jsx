import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Dashboard() {

    return (
        <div>
            <input 
                className = "search_box"
                type = "text"
                placeholder = "Search Groceries"
            />
            <div className = "grocery_data">
            {/* map the below div against your grocery data */}
                {/* <div>
                    <h3> name </h3>
                    <div> price </div>
                </div> */}
            </div>
        </div>
    )
}