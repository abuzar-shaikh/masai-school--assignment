import React from "react";

const CofeeCard = () => {
  return (
    <div className="coffee_card">
      <img />
      <div>
        <h2 className="title">{/* coffee name */}</h2>
        <p className="price">{/* coffee price */}</p>
        <p>{/* coffee description */}</p>

        {/* map ingredients intside li into ul(ul tag have class - ingredients) */}
      </div>
    </div>
  );
};

export default CofeeCard;
