import React from "react";

const Cofee = () => {

  // get coffee data from json server use useEffect and useState

  return (
    <div className="coffee_container">{/* map coffee into coffee card */}</div>
  );
};

export default Cofee;
