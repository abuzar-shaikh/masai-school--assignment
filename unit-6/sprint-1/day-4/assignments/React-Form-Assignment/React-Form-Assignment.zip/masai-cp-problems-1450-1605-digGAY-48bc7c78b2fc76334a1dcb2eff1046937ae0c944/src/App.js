import React from "react";
import Form from "./Components/Form";
import "./App.css";

const App = () => {
  return (
    <div className="App">
      <Form />
    </div>
  );
};

export default App;
