import React from "react";
import "./Form.css";

const Form = () => {
  return (
    <div>
      <div>
        <form onSubmit={() => {}}>
          {/* First Name */}

          {/* Last Name */}

          {/* Email */}

          {/* Password */}

          {/* Phone number */}

          {/* Country Select Tage */}

          {/* Birth Date Selector */}

          {/* Profile Pic Selector */}

          {/* Married Status Selector */}

          {/* Gender Selector */}

          {/* Submit Button - input type submit */}
        </form>
        {/* if form submitted then show ShowFormData component here */}
      </div>
    </div>
  );
};

export default Form;
