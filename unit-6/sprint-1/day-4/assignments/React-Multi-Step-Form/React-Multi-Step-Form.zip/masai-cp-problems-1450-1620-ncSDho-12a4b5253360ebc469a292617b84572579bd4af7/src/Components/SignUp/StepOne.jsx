import React from "react";

const StepOne = () => {
  return <div>StepOne</div>;
};

export default StepOne;
