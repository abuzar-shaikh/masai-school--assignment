import React from "react";

const StepThree = () => {
  return <div>StepThree</div>;
};

export default StepThree;
