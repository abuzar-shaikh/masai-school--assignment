import React from "react";

const SignUp = () => {
  return <div>{/* create form and render component according to steps */}</div>;
};

export default SignUp;
