import React from "react";

const UserInfo = () => {
  return <div>UserInfo</div>;
};

export default UserInfo;
