import React from "react";

const StepTwo = () => {
  return <div>StepTwo</div>;
};

export default StepTwo;
