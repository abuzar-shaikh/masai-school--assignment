import React from "react";

const StepFour = () => {
  return <div>StepFour</div>;
};

export default StepFour;
