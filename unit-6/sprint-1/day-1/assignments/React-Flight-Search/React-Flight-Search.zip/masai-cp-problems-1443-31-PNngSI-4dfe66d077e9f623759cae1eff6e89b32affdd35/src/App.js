import React from "react";

function App() {
  return (
    <div>
//    add FlightSearch Component
    </div>
  );
}

export default App;
