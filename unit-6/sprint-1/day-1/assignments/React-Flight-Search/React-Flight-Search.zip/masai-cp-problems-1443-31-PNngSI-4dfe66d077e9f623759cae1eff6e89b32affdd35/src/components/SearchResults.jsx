const SearchResults = (props) => {
      return (
          <table >
            {/* add columnsheadings */}
            <tbody data-testid="flight-results">{
          //  map through the results and display as rows
            }</tbody>
          </table>
      );
    
  };
  export default SearchResults;
  