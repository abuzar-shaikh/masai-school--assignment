import React from "react";

const MovieCard = () => {
  return <div data-testid="movie-card"></div>;
};

export default MovieCard;
