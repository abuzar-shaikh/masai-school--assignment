import React from "react";

const AddMovie = () => {
  return (
    <div data-testid="add-movie">
      <h1>Add Movie</h1>
      <form data-testid="add-movie-form"></form>
    </div>
  );
};

export default AddMovie;
