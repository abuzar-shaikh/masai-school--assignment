//Complete the reducer function logic inside the curly braces {}
const reducer = () => {};

export { reducer };
