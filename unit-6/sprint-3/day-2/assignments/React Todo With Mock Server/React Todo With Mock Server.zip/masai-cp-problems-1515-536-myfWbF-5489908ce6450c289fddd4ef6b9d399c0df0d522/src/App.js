import Todo from "./Components/Todo";

function App() {
  return <>{/* add Todo component here */}</>;
}

export default App;
