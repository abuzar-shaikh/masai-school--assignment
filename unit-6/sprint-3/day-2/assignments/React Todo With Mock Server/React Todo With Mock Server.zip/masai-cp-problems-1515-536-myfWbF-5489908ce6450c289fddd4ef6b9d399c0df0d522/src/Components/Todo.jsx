
const Todos = () => {
  

  return (
    <div>
    {/* add TodoInput component here */}
    {/* map through the todos array and display the tasks */}
    </div>
  );
};

export default Todos;
