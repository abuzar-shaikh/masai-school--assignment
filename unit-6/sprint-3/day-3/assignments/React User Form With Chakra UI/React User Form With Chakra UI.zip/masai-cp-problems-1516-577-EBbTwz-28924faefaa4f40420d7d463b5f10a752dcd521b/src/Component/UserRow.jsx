import React from "react";

// use Td component from  from chakra ui to display the user details
const UserRow = ({ name, gender, role, maritalStatus, id }) => {
  return <></>;
};
export { UserRow };
